const express = require('express');
const router = express.Router();
const axios = require('axios');
const { Account, Destination } = require('../models');

router.post('/incoming_data', async (req, res) => {
  const token = req.headers['cl-x-token'];
  const data = req.body;

  if (!token) return res.json({ message: 'Un Authenticate' });
  if (!data || typeof data !== 'object') return res.json({ message: 'Invalid Data' });

  const account = await Account.findOne({ where: { appSecretToken: token } });
  if (!account) return res.json({ message: 'Un Authenticate' });

  const destinations = await Destination.findAll({ where: { AccountId: account.id } });

  for (const dest of destinations) {
    const headers = dest.headers;
    const url = dest.url;
    const method = dest.method.toUpperCase();

    try {
      if (method === 'GET') {
        await axios.get(url, { params: data, headers });
      } else if (method === 'POST') {
        await axios.post(url, data, { headers });
      } else if (method === 'PUT') {
        await axios.put(url, data, { headers });
      }
    } catch (err) {
      console.error(`Failed to send to ${url}:`, err.message);
    }
  }

  res.json({ message: 'Data pushed to all destinations' });
});

module.exports = router;
