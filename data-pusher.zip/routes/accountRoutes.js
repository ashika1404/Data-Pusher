const express = require('express');
const router = express.Router();
const { Account, Destination } = require('../models');
const { randomUUID } = require('crypto');

router.post('/', async (req, res) => {
  try {
    const { email, accountName, website } = req.body;
    const appSecretToken = randomUUID();
    const account = await Account.create({ email, accountName, website, appSecretToken });
    res.json(account);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/', async (req, res) => {
  const accounts = await Account.findAll();
  res.json(accounts);
});

router.put('/:id', async (req, res) => {
  try {
    await Account.update(req.body, { where: { id: req.params.id } });
    const updated = await Account.findByPk(req.params.id);
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await Account.destroy({ where: { id: req.params.id } });
    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/:id/destinations', async (req, res) => {
  const destinations = await Destination.findAll({ where: { AccountId: req.params.id } });
  res.json(destinations);
});

module.exports = router;
