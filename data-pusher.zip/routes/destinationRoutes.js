const express = require('express');
const router = express.Router();
const { Destination } = require('../models');

router.post('/', async (req, res) => {
  try {
    const destination = await Destination.create(req.body);
    res.json(destination);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/', async (req, res) => {
  const destinations = await Destination.findAll();
  res.json(destinations);
});

router.put('/:id', async (req, res) => {
  await Destination.update(req.body, { where: { id: req.params.id } });
  const updated = await Destination.findByPk(req.params.id);
  res.json(updated);
});

router.delete('/:id', async (req, res) => {
  await Destination.destroy({ where: { id: req.params.id } });
  res.json({ message: 'Deleted successfully' });
});

module.exports = router;
