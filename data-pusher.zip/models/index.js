const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize({ dialect: 'sqlite', storage: './database.sqlite' });

const Account = sequelize.define('Account', {
  email: { type: DataTypes.STRING, allowNull: false, unique: true },
  accountName: { type: DataTypes.STRING, allowNull: false },
  website: { type: DataTypes.STRING },
  appSecretToken: { type: DataTypes.STRING, allowNull: false, unique: true },
});

const Destination = sequelize.define('Destination', {
  url: { type: DataTypes.STRING, allowNull: false },
  method: { type: DataTypes.STRING, allowNull: false },
  headers: { type: DataTypes.JSON, allowNull: false },
});

Account.hasMany(Destination, { onDelete: 'CASCADE' });
Destination.belongsTo(Account);

module.exports = { sequelize, Account, Destination };
